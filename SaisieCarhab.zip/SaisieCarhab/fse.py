# -*- coding: utf-8 -*-
from utils_job import popup
        
class ImportFSE(object):
    """
    /***************************************************************************
     Import FSE Class
            
            Convert FSE layer (csv) to carhab layer format (sqlite).
     ***************************************************************************/
     """
    def __init__(self):
        """ Constructor. """
        
        
        pass
        
    def run(self):
        '''Specific stuff at tool activating.'''
        
        popup("Import FSE : c\'est pour bientôt !")
        
class ExportFSE(object):
    """
    /***************************************************************************
     Import FSE Class
            
            Convert FSE layer (csv) to carhab layer format (sqlite).
     ***************************************************************************/
     """
    def __init__(self):
        """ Constructor. """
        
        
        pass
        
    def run(self):
        '''Specific stuff at tool activating.'''
        
        popup("Export FSE : c\'est pour bientôt !")
        